$(document).ready(function (){
    ripples
    $(".header, .py-5 , .info").ripples({
        dropRadius: 1,
        perturbance: 0.01,
      });

      //magnific popup

      $(".parent-container").magnificPopup({
          delegate: 'a',
          type: 'image',
          gallery: {
              enabled: 'true'
       }
      });
});