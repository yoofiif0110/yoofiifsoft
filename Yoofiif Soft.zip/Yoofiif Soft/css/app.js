// var m ;
// console.log(typeof(m));
// var stType = ['kindergarten','elementary','highschool','higher education'];
// console.log(stType[0]);
// var a = [1,2,3,4]
// console.log(typeof(a));
// var person = null;
// console.log(typeof(person))
// person = undefined;
// console.log(typeof(person));
// console.log(null === undefined);
// console.log(undefined == null);

// Objects
var car = {

name:"Cobra",
model:'123KL',
color:"white",
weight:123
}
var numbers = [122,33,4,-1,78,0]
numbers.sort( function(a,b) {return b - a} );

var car1 = ['ana', 'sii', 'ishee'];
car1[car1.length] = 'ishee';
car1[car1.length] = 'isaan';

car1.splice(1,2,"Volvo","asasasa")
// car1.unshift('ss');
// var c2 = car1.shift();

// delete car1[0];
// car1.push('less')
// car1.pop();
// car1[car1.length] = 'hh';
var bys = ['adugna', 'Abdi' ]
var grls = ['sidise', 'Leelloo']
var chldrn = bys.concat(grls);

var d = new Date();
function greetings()
{
  
  var currentHour = d.getHours();
  var greeting = "greeeting";
 switch(currentHour/6)
 {
   case 0:
   case 1:
     greeting = "Good morning";
     break;
   case 2:
     case 3:
       greeting = "Goood After noon"
      break
       default :
       greeting = "Good Eveniing"
 }
 return greeting ;
}

// function far()
// {
//   for(i=0, len=car1.length,text=""; i<len; i++)
//   {
//     text += car1[i] + "</br>";
//   }
//   return text;
// }


// car1.sort();
// car1.reverse();
// car1.shift()
 document.getElementById(2).innerHTML = obj();
 document.getElementById(3).innerHTML = far();
function myfun(name,age)
{
      
  return name * age;
     
}

function showInt(){
  var x = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thrusday", "Friday", "Sunday"];
  var date = new Date();
  date.setFullYear(2019,2,11);
  document.getElementById(1).innerHTML = date;

}
function refresh(){
  document.getElementById(1).innerHTML = "Hello World"
}
// myfun("Yoofiif",22);